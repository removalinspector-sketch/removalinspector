# Removal Inspector — Cloudflare Pages Deployment

State-of-art branded v3 — logo embedded, fully functional.

## Deploy to Cloudflare Pages (Fastest for SA)

### Option 1: Drag & Drop (30 seconds) — RECOMMENDED
1. Go to https://dash.cloudflare.com → Pages → Create a project → Direct Upload
2. Project name: `removal-inspector`
3. Drag & drop `index.html` (or whole folder) → Deploy
4. Live instantly at `removal-inspector.pages.dev` — add custom domain in 1 click

### Option 2: Connect GitHub (Auto-deploy)
1. Push this folder to GitHub (same as GitHub Pages)
2. Cloudflare Dashboard → Pages → Create → Connect to Git → Select repo `removal-inspector`
3. Build settings: 
   - Framework preset: None
   - Build command: (leave empty)
   - Build output directory: /
4. Deploy → auto-deploys on every git push

### Option 3: Wrangler CLI (from your PC)
```bash
npm install -g wrangler
wrangler login
wrangler pages deploy . --project-name=removal-inspector
```

## Custom Domain (removalinspector.co.za)
1. In Cloudflare Pages → Custom domains → Set up custom domain
2. Enter `removalinspector.co.za` or `www.removalinspector.co.za`
3. If domain is on Cloudflare: auto SSL + DNS in 30 sec
4. If domain elsewhere: add CNAME record pointing to `removal-inspector.pages.dev`

## Files Included
- index.html — self-contained (logo base64 embedded, 395KB)
- _headers — security + caching
- _redirects — SPA routing
- assets/logo.jpg — original logo
- wrangler.toml — CLI config

## Why Cloudflare vs GitHub Pages?
- Faster in South Africa (JNB/CPT edge)
- Free SSL, free custom domain
- No branch settings — just upload
- Better caching for your 136KB logo + 395KB HTML

## PayFast Links
alu9y • w2pna • 21qvd • d037g • 45p36 • i1wd9 — exact old wording

## WhatsApp
075 793 1848

Built branded user-friendly v3 — mobile-first, 56px touch targets.
